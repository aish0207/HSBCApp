// Default input for authentication simulation
var userInput = '1'; // 1 = Success, any other value = Failure

// Expose functionality to set input dynamically
rpc.exports = {
    setinput: function (input) {
        userInput = input;
        console.log('[Frida] Input set to:', userInput);
    },
};

Java.perform(function () {
    console.log('[Frida] Starting Biometric hooks...');

    // Hook BiometricManager
    try {
        var BiometricManager = Java.use('android.hardware.biometrics.BiometricManager');
        BiometricManager.canAuthenticate.overload().implementation = function () {
            console.log('[Frida] Intercepted BiometricManager.canAuthenticate() - returning SUCCESS');
            return 0; // BIOMETRIC_SUCCESS
        };
    } catch (e) {
        console.log('[Frida] BiometricManager not found. Trying AndroidX version...');
        try {
            var AndroidXBiometricManager = Java.use('androidx.biometric.BiometricManager');
            AndroidXBiometricManager.canAuthenticate.overload().implementation = function () {
                console.log('[Frida] Intercepted AndroidX BiometricManager.canAuthenticate() - returning SUCCESS');
                return 0; // BIOMETRIC_SUCCESS
            };
        } catch (e2) {
            console.log('[Frida] Error hooking AndroidX BiometricManager:', e2);
        }
    }

    // Hook BiometricPrompt
    try {
        var BiometricPrompt = Java.use('android.hardware.biometrics.BiometricPrompt');
        var AuthenticationResult = BiometricPrompt.AuthenticationResult;
        var CryptoObject = BiometricPrompt.CryptoObject;

        // Helper to create AuthenticationResult
        function createAuthResult() {
            var cryptoObj = null;
            var authenticationType = 1; // BIOMETRIC
            return AuthenticationResult.$new(cryptoObj, authenticationType);
        }

        BiometricPrompt.authenticate.overload(
            'android.os.CancellationSignal',
            'java.util.concurrent.Executor',
            'android.hardware.biometrics.BiometricPrompt$AuthenticationCallback'
        ).implementation = function (cancellationSignal, executor, callback) {
            console.log('[Frida] Intercepted BiometricPrompt.authenticate()');
            if (userInput === '1') {
                console.log('[Frida] Simulating Authentication Success');
                var result = createAuthResult();
                Java.scheduleOnMainThread(function () {
                    callback.onAuthenticationSucceeded(result);
                });
            } else {
                console.log('[Frida] Simulating Authentication Failure');
                Java.scheduleOnMainThread(function () {
                    callback.onAuthenticationFailed();
                });
            }
        };
    } catch (e) {
        console.log('[Frida] BiometricPrompt not found. Trying AndroidX version...');
        try {
            var AndroidXBiometricPrompt = Java.use('androidx.biometric.BiometricPrompt');

            AndroidXBiometricPrompt.authenticate.overload(
                'androidx.biometric.BiometricPrompt$PromptInfo'
            ).implementation = function (promptInfo) {
                console.log('[Frida] Intercepted AndroidX BiometricPrompt.authenticate()');
                var callback = this.mAuthenticationCallback.value;
                if (userInput === '1') {
                    console.log('[Frida] Simulating AndroidX Authentication Success');
                    Java.scheduleOnMainThread(function () {
                        callback.onAuthenticationSucceeded(null);
                    });
                } else {
                    console.log('[Frida] Simulating AndroidX Authentication Failure');
                    Java.scheduleOnMainThread(function () {
                        callback.onAuthenticationFailed();
                    });
                }
            };
        } catch (e2) {
            console.log('[Frida] Error hooking AndroidX BiometricPrompt:', e2);
        }
    }
});
