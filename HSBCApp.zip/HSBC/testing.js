var imagePath = ''; // Path to the replacement image

rpc.exports = {
    init(stage, parameters) {
        imagePath = parameters.image; // Pass replacement image path
        console.log("Image Path Initialized: " + imagePath);
    },
    dispose() {
        console.log("[dispose]");
    },
};

(function () {
    'use strict';

    if (Java.available) {
        Java.perform(function () {
            try {
                console.log("[+] Frida Hook Started for Camera Intent Injection");

                // Required Classes
                var Intent = Java.use('android.content.Intent');
                var BitmapFactory = Java.use('android.graphics.BitmapFactory');
                var Bitmap = Java.use('android.graphics.Bitmap');
                var Uri = Java.use('android.net.Uri');
                var ContentResolver = Java.use('android.content.ContentResolver');
                var CompressFormat = Java.use('android.graphics.Bitmap$CompressFormat');

                // Hook onActivityResult
                var Activity = Java.use('android.app.Activity');
                Activity.onActivityResult.overload('int', 'int', 'android.content.Intent').implementation = function (requestCode, resultCode, data) {
                    console.log("[+] Inside onActivityResult Hook");
                    
                    if (resultCode === -1 && data && imagePath) { // -1: RESULT_OK
                        var outputUri = data.getParcelableExtra("output");
                        if (outputUri) {
                            console.log("[+] Output URI found: " + outputUri);

                            try {
                                // Replace the image with a custom one
                                var resolver = this.getContentResolver();
                                var outputStream = resolver.openOutputStream(outputUri);
                                if (outputStream) {
                                    var replacementBitmap = loadReplacementImage();
                                    if (replacementBitmap) {
                                        replacementBitmap.compress(CompressFormat.JPEG.value, 100, outputStream);
                                        outputStream.close();
                                        console.log("[+] Image successfully injected into URI: " + outputUri);
                                    } else {
                                        console.log("[-] Failed to load replacement image");
                                    }
                                } else {
                                    console.log("[-] Unable to open output stream for URI");
                                }
                            } catch (e) {
                                console.log("[-] Error during image replacement: " + e);
                            }
                        } else {
                            console.log("[-] No output URI found in Intent");
                        }
                    } else {
                        console.log("[+] Skipping image injection: No imagePath or invalid result");
                    }

                    // Call the original implementation
                    return this.onActivityResult(requestCode, resultCode, data);
                };

                // Load replacement image from file
                function loadReplacementImage() {
                    try {
                        var file = Java.use('java.io.File').$new(imagePath);
                        if (!file.exists()) {
                            console.log("[-] Replacement image not found at: " + imagePath);
                            return null;
                        }

                        var fis = Java.use('java.io.FileInputStream').$new(file);
                        return BitmapFactory.decodeStream(fis);
                    } catch (e) {
                        console.log("[-] Error loading replacement image: " + e);
                        return null;
                    }
                }
            } catch (err) {
                console.log("[-] Error: " + err.stack);
            }
        });
    }
})();
